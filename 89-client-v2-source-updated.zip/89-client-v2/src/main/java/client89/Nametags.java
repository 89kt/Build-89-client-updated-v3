package client89;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2fStack;

/**
 * Clean nametag: [held item name]
 *                [offhand | helmet chest legs boots | mainhand]
 *                [ name  hp  distance ]
 */
public final class Nametags {
    private static final int SLOT = 18;

    public static void render(DrawContext c, MinecraftClient mc, float td) {
        if (!mc.options.getPerspective().isFirstPerson()) return;
        int w = c.getScaledWindowWidth();
        int h = c.getScaledWindowHeight();
        Vec3d cam = mc.player.getCameraPosVec(td);
        TextRenderer tr = mc.textRenderer;
        float userScale = Modules.NAMESCALE.enabled ? Modules.NAMESCALE.setting.value : 1.0f;
        float range = Modules.NAMETAGS.setting.value; // up to 500 blocks

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isSpectator()) continue;
            Vec3d pos = p.getLerpedPos(td).add(0.0, p.getHeight() + 0.4, 0.0);
            double dist = cam.distanceTo(pos);
            if (dist > range) continue;
            Projection.Pt pt = Projection.project(mc, td, pos, w, h);
            if (pt.behind() || pt.x() < -150 || pt.x() > w + 150 || pt.y() < -150 || pt.y() > h + 150) continue;

            float sc = (float) MathHelper.clamp(14.0 / dist, 0.5, 1.0) * userScale;

            // --- gear (only drawn when close enough to be readable) ---
            ItemStack main = p.getMainHandStack();
            ItemStack off = p.getOffHandStack();
            List<ItemStack> gear = new ArrayList<>();
            List<Integer> kind = new ArrayList<>(); // 0 = offhand, 1 = armor, 2 = mainhand
            if (dist <= 100.0) {
                if (!off.isEmpty()) { gear.add(off); kind.add(0); }
                for (EquipmentSlot es : new EquipmentSlot[] {
                        EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET }) {
                    ItemStack s = p.getEquippedStack(es);
                    if (!s.isEmpty()) { gear.add(s); kind.add(1); }
                }
                if (!main.isEmpty()) { gear.add(main); kind.add(2); }
            }

            // --- name pill content ---
            String name = p.getName().getString();
            float hpVal = p.getHealth() + p.getAbsorptionAmount();
            String hp = String.format("%.0f", hpVal);
            String ds = Math.round(dist) + "m";
            int hpCol = Render2D.lerp(0xFFE53935, 0xFF2EAD5B, MathHelper.clamp(hpVal / p.getMaxHealth(), 0f, 1f));
            int nameW = tr.getWidth(name), hpW = tr.getWidth(hp), dsW = tr.getWidth(ds);
            int boxW = nameW + hpW + dsW + 26;
            int boxH = 14;

            Matrix3x2fStack m = c.getMatrices();
            m.pushMatrix();
            m.translate(pt.x(), pt.y());
            m.scale(sc, sc);

            int bx = -boxW / 2, by = -boxH;
            Render2D.rrect(c, bx, by, boxW, boxH, 5, 0xEEFFFFFF);
            Render2D.hgrad(c, bx + 4, by + boxH - 1, boxW - 8, 1, Theme.accent(), Theme.accent2());
            int tx = bx + 6;
            c.drawText(tr, name, tx, by + 3, Theme.TEXT, false);
            tx += nameW + 6;
            c.drawText(tr, hp, tx, by + 3, hpCol, false);
            tx += hpW + 6;
            c.drawText(tr, ds, tx, by + 3, Theme.DIM, false);

            if (!gear.isEmpty()) {
                int n = gear.size();
                int rowW = n * SLOT;
                int ix = -rowW / 2;
                int iy = by - 24;
                Render2D.rrect(c, ix - 2, iy - 3, rowW + 4, 24, 5, 0xE6FFFFFF);
                for (int i = 0; i < n; i++) {
                    ItemStack s = gear.get(i);
                    int x = ix + i * SLOT + 1;
                    c.drawItem(s, x, iy);
                    c.drawStackOverlay(tr, s, x, iy); // count + durability bar
                    int k = kind.get(i);
                    if (k == 2) c.fill(x, iy + 18, x + 16, iy + 19, Theme.accent());
                    else if (k == 0) c.fill(x + 3, iy + 18, x + 13, iy + 19, Theme.DIM);
                }
                // held item name, tiny pill above the row
                if (!main.isEmpty() && dist <= 60.0) {
                    String hn = main.getName().getString();
                    int hw = tr.getWidth(hn);
                    int hy = iy - 16;
                    Render2D.rrect(c, -hw / 2 - 4, hy, hw + 8, 12, 4, 0xE6FFFFFF);
                    c.drawText(tr, hn, -hw / 2, hy + 2, Theme.accent(), false);
                }
            }
            m.popMatrix();
        }
    }
}
