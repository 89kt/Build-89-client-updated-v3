package client89;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix3x2fStack;

public final class Render2D {
    public static int alpha(int c, float a) {
        int al = (int) ((c >>> 24) * MathHelper.clamp(a, 0.0f, 1.0f));
        return al << 24 | c & 0xFFFFFF;
    }

    public static int lerp(int a, int b, float t) {
        t = MathHelper.clamp(t, 0.0f, 1.0f);
        int al = (int) ((a >>> 24) + ((b >>> 24) - (a >>> 24)) * t);
        int r = (int) ((a >> 16 & 255) + ((b >> 16 & 255) - (a >> 16 & 255)) * t);
        int g = (int) ((a >> 8 & 255) + ((b >> 8 & 255) - (a >> 8 & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return al << 24 | r << 16 | g << 8 | bl;
    }

    public static float ease(float t) { float x = 1.0f - t; return 1.0f - x * x * x; }

    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < r; ++i) {
            double dy = (r - i) - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
        c.fill(x, y + r, x + w, y + h - r, color);
    }

    public static void hgrad(DrawContext c, int x, int y, int w, int h, int c1, int c2) {
        for (int i = 0; i < w; i += 2) {
            c.fill(x + i, y, Math.min(x + i + 2, x + w), y + h, lerp(c1, c2, (float) i / (float) w));
        }
    }

    public static void line(DrawContext c, float x1, float y1, float x2, float y2, int color) {
        float dx = x2 - x1, dy = y2 - y1;
        float len = Math.min((float) Math.sqrt(dx * dx + dy * dy), 4000.0f);
        if (len < 1.0f) return;
        Matrix3x2fStack m = c.getMatrices();
        m.pushMatrix();
        m.translate(x1, y1);
        m.rotate((float) Math.atan2(dy, dx));
        c.fill(0, 0, (int) len, 1, color);
        m.popMatrix();
    }

    /** Text that slowly pulses between accent and accent2. */
    public static int wave(DrawContext c, TextRenderer tr, String s, int x, int y, float a) {
        float time = (Util.getMeasuringTimeMs() % 3000L) / 3000.0f;
        int cx = x;
        for (int i = 0; i < s.length(); ++i) {
            String ch = String.valueOf(s.charAt(i));
            float t = (float) (Math.sin(time * Math.PI * 2.0 - i * 0.5) * 0.5 + 0.5);
            c.drawText(tr, ch, cx, y, alpha(lerp(Theme.accent(), Theme.accent2(), t), a), false);
            cx += tr.getWidth(ch);
        }
        return cx;
    }

    public static void centered(DrawContext c, TextRenderer tr, String s, int cx, int y, int color, boolean shadow) {
        c.drawText(tr, s, cx - tr.getWidth(s) / 2, y, color, shadow);
    }
}
