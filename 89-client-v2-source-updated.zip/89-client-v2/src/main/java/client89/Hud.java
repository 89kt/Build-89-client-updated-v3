package client89;

import java.util.ArrayList;
import java.util.Comparator;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public final class Hud {
    public static void render(DrawContext c, RenderTickCounter counter) {
        for (Module m : Modules.ALL) m.tick();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        float td = counter.getTickProgress(false);
        TextRenderer tr = mc.textRenderer;

        if (Modules.TRACERS.enabled) Tracers.render(c, mc, td);
        if (Modules.NAMETAGS.enabled) Nametags.render(c, mc, td);
        HitFx.render(c, mc, td);

        if (Modules.WATERMARK.anim > 0.02f) {
            float a = Modules.WATERMARK.anim;
            String num = "89";
            String title = " client v2";
            String fps = "  " + mc.getCurrentFps() + " fps";
            int w = tr.getWidth(num) + tr.getWidth(title) + tr.getWidth(fps) + 14;
            Render2D.rrect(c, 6, 6, w, 16, 5, Render2D.alpha(0xEEFFFFFF, a));
            Render2D.hgrad(c, 9, 20, w - 6, 1, Render2D.alpha(Theme.accent(), a), Render2D.alpha(Theme.accent2(), a));
            int x = Render2D.wave(c, tr, num, 13, 10, a);
            c.drawText(tr, title, x, 10, Render2D.alpha(Theme.TEXT, a), false);
            x += tr.getWidth(title);
            c.drawText(tr, fps, x, 10, Render2D.alpha(Theme.DIM, a), false);
        }

        if (Modules.MODULELIST.enabled) {
            ArrayList<Module> on = new ArrayList<>();
            for (Module m : Modules.ALL) {
                if (m.anim > 0.02f && m != Modules.MODULELIST) on.add(m);
            }
            on.sort(Comparator.comparingInt(m -> -tr.getWidth(m.name)));
            int sw = c.getScaledWindowWidth();
            int y = 6, i = 0;
            for (Module m : on) {
                int w = tr.getWidth(m.name) + 10;
                float a = m.anim;
                int x = sw - 6 - w + (int) ((1.0f - Render2D.ease(a)) * (w + 10));
                int col = Render2D.lerp(Theme.accent(), Theme.accent2(), (i++ % 6) / 5.0f);
                Render2D.rrect(c, x, y, w, 13, 4, Render2D.alpha(0xEEFFFFFF, a));
                c.fill(x + w - 2, y + 2, x + w, y + 11, Render2D.alpha(col, a));
                c.drawText(tr, m.name, x + 4, y + 3, Render2D.alpha(Theme.accent(), a), false);
                y += (int) (14.0f * a);
            }
        }
    }
}
