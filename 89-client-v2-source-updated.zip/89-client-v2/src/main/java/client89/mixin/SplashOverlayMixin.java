package client89.mixin;

import client89.Render2D;
import client89.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix3x2fStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** White + red "89 client v2" loading screen drawn over the vanilla Mojang one. */
@Mixin(SplashOverlay.class)
public abstract class SplashOverlayMixin {
    @Shadow private long reloadCompleteTime;
    @Shadow private float progress;

    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void client89$render(DrawContext c, int mx, int my, float delta, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();
        long now = Util.getMeasuringTimeMs();
        float f = reloadCompleteTime > -1L ? (now - reloadCompleteTime) / 1000.0f : -1.0f;
        float a = f >= 1.0f ? 1.0f - MathHelper.clamp(f - 1.0f, 0.0f, 1.0f) : 1.0f;
        if (a <= 0.01f) return;

        int red = 0xFFE53935, red2 = Render2D.lerp(red, 0xFFFFFFFF, 0.38f);
        c.fill(0, 0, w, h, Render2D.alpha(0xFFFFFFFF, a));
        // faint red glow at the bottom
        c.fillGradient(0, h - h / 3, w, h, Render2D.alpha(0x00E53935, a), Render2D.alpha(0x22E53935, a));

        Matrix3x2fStack m = c.getMatrices();
        m.pushMatrix();
        m.translate(w / 2.0f, h / 2.0f - 14);
        m.scale(5.0f, 5.0f);
        String big = "89";
        c.drawText(tr, big, -tr.getWidth(big) / 2, -4, Render2D.alpha(red, a), false);
        m.popMatrix();

        m.pushMatrix();
        m.translate(w / 2.0f, h / 2.0f + 14);
        m.scale(1.6f, 1.6f);
        String sub = "client v2";
        c.drawText(tr, sub, -tr.getWidth(sub) / 2, 0, Render2D.alpha(0xFF222226, a), false);
        m.popMatrix();

        int bw = 140, bx = w / 2 - bw / 2, by = h / 2 + 40;
        Render2D.rrect(c, bx, by, bw, 4, 2, Render2D.alpha(0xFFE4E4E8, a));
        int fw = Math.max(2, (int) (bw * MathHelper.clamp(progress, 0.0f, 1.0f)));
        Render2D.hgrad(c, bx, by, fw, 4, Render2D.alpha(red, a), Render2D.alpha(red2, a));

        Render2D.centered(c, tr, "made by 89_kt", w / 2, h - 14, Render2D.alpha(0xFF8A8A92, a), false);
    }
}
