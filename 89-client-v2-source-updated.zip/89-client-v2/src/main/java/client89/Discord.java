package client89;

import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.UnixDomainSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;

/**
 * Discord Rich Presence over Discord's local IPC socket / named pipe. No extra libraries needed.
 *
 * Setup: create an application called "89 client" at https://discord.com/developers/applications,
 * paste its Application ID below (or into config/89-client.properties as discord.clientId),
 * and upload icon.png under Rich Presence > Art Assets with the key "logo89".
 */
public final class Discord {
    public static final String DEFAULT_CLIENT_ID = "1559163767043129445";
    public static final String LARGE_IMAGE_KEY = "logo89";

    public static volatile String clientId = DEFAULT_CLIENT_ID;
    private static volatile String state = "In the menus";
    private static volatile boolean wanted = true;
    private static boolean started;
    private static final long START = System.currentTimeMillis() / 1000L;
    private static final String FORCE = "\u0000force";

    private Discord() { }

    public static synchronized void start() {
        if (started) return;
        started = true;
        Thread t = new Thread(Discord::run, "89client-discord");
        t.setDaemon(true);
        t.start();
    }

    /** Runs on the game thread; just snapshots what the background thread should show. */
    public static void tick(MinecraftClient mc) {
        wanted = Modules.DISCORD.enabled;
        String s;
        if (mc.world == null) {
            s = "In the menus";
        } else if (mc.isInSingleplayer()) {
            s = "Singleplayer";
        } else {
            ServerInfo si = mc.getCurrentServerEntry();
            boolean hide = Modules.DISCORD.setting != null && Modules.DISCORD.setting.index == 1;
            s = (si != null && !hide) ? "Playing " + si.address : "Multiplayer";
        }
        state = s;
    }

    private static boolean validId() { return clientId != null && clientId.matches("\\d{15,25}"); }

    // ---------------------------------------------------------------- worker thread

    private static void run() {
        Transport tr = null;
        String sent = FORCE;
        long nextTry = 0;
        while (true) {
            try {
                if (!validId()) { Thread.sleep(5000); continue; }
                String want = wanted ? state : null;
                if (tr == null) {
                    if (!wanted || System.currentTimeMillis() < nextTry) { Thread.sleep(1500); continue; }
                    tr = connect();
                    if (tr == null) { nextTry = System.currentTimeMillis() + 15000; continue; }
                    sent = FORCE;
                }
                if (!Objects.equals(want, sent)) {
                    setActivity(tr, want);
                    sent = want;
                }
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                return;
            } catch (Throwable e) {
                if (tr != null) tr.close();
                tr = null;
                nextTry = System.currentTimeMillis() + 10000;
            }
        }
    }

    private static void setActivity(Transport tr, String stateText) throws IOException {
        JsonObject args = new JsonObject();
        args.addProperty("pid", ProcessHandle.current().pid());
        if (stateText != null) {
            JsonObject act = new JsonObject();
            act.addProperty("details", "89 client v2");
            act.addProperty("state", stateText);
            JsonObject ts = new JsonObject();
            ts.addProperty("start", START);
            act.add("timestamps", ts);
            JsonObject assets = new JsonObject();
            assets.addProperty("large_image", LARGE_IMAGE_KEY);
            assets.addProperty("large_text", "89 client v2");
            act.add("assets", assets);
            args.add("activity", act);
        }
        JsonObject root = new JsonObject();
        root.addProperty("cmd", "SET_ACTIVITY");
        root.add("args", args);
        root.addProperty("nonce", UUID.randomUUID().toString());
        send(tr, 1, root.toString());
        for (int i = 0; i < 6; i++) { // swallow pings until the reply arrives
            Frame f = read(tr);
            if (f.op == 1) return;
        }
    }

    private static Transport connect() {
        for (int i = 0; i < 10; i++) {
            Transport tr = null;
            try {
                tr = open(i);
                if (tr == null) continue;
                JsonObject hs = new JsonObject();
                hs.addProperty("v", 1);
                hs.addProperty("client_id", clientId);
                send(tr, 0, hs.toString());
                read(tr); // READY
                return tr;
            } catch (Throwable e) {
                if (tr != null) tr.close();
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- framing

    private record Frame(int op, String data) { }

    private static void send(Transport tr, int op, String json) throws IOException {
        byte[] d = json.getBytes(StandardCharsets.UTF_8);
        ByteBuffer bb = ByteBuffer.allocate(8 + d.length).order(ByteOrder.LITTLE_ENDIAN);
        bb.putInt(op).putInt(d.length).put(d);
        tr.write(bb.array());
    }

    private static Frame read(Transport tr) throws IOException {
        byte[] head = new byte[8];
        tr.readFully(head);
        ByteBuffer hb = ByteBuffer.wrap(head).order(ByteOrder.LITTLE_ENDIAN);
        int op = hb.getInt(), len = hb.getInt();
        if (len < 0 || len > (1 << 20)) throw new IOException("bad frame");
        byte[] body = new byte[len];
        tr.readFully(body);
        String data = new String(body, StandardCharsets.UTF_8);
        if (op == 2) throw new IOException("closed by discord");
        if (op == 3) send(tr, 4, data); // ping -> pong
        return new Frame(op, data);
    }

    // ---------------------------------------------------------------- transports

    private interface Transport {
        void write(byte[] b) throws IOException;
        void readFully(byte[] b) throws IOException;
        void close();
    }

    private static Transport open(int i) throws IOException {
        boolean win = System.getProperty("os.name", "").toLowerCase().contains("win");
        if (win) {
            RandomAccessFile f = new RandomAccessFile("\\\\?\\pipe\\discord-ipc-" + i, "rw");
            return new Transport() {
                public void write(byte[] b) throws IOException { f.write(b); }
                public void readFully(byte[] b) throws IOException { f.readFully(b); }
                public void close() { try { f.close(); } catch (IOException ignored) { } }
            };
        }
        String[] bases = {
            System.getenv("XDG_RUNTIME_DIR"), System.getenv("TMPDIR"),
            System.getenv("TMP"), System.getenv("TEMP"), "/tmp"
        };
        String[] subs = { "", "snap.discord/", "app/com.discordapp.Discord/", "app/com.discordapp.DiscordCanary/" };
        for (String b : bases) {
            if (b == null || b.isEmpty()) continue;
            for (String sub : subs) {
                Path p = Path.of(b, sub + "discord-ipc-" + i);
                if (!Files.exists(p)) continue;
                try {
                    SocketChannel ch = SocketChannel.open(UnixDomainSocketAddress.of(p));
                    return new Transport() {
                        public void write(byte[] bytes) throws IOException {
                            ByteBuffer bb = ByteBuffer.wrap(bytes);
                            while (bb.hasRemaining()) ch.write(bb);
                        }
                        public void readFully(byte[] bytes) throws IOException {
                            ByteBuffer bb = ByteBuffer.wrap(bytes);
                            while (bb.hasRemaining()) if (ch.read(bb) < 0) throw new IOException("eof");
                        }
                        public void close() { try { ch.close(); } catch (IOException ignored) { } }
                    };
                } catch (IOException ignored) { }
            }
        }
        return null;
    }
}
